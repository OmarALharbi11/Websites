<?php

$base = '/trackdownn/app/';
$req  = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$path = substr($req, strlen($base));


if ($path && file_exists(__DIR__ . '/' . $path)) {
    return false;               
}


readfile(__DIR__ . '/index.html');
exit;
?>
