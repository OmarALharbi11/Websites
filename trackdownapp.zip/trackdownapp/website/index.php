<?php
include 'partials.php';
render_header('Track Down | Home');
?>

<section class="hero fancy">
  <div class="hero-text">
    <h2>Your all-in-one&nbsp;health&nbsp;journal</h2>
    <p>
      Track calories, workouts, and daily habits in one simple place.<br>
      Stay motivated on your journey to a healthier life.
    </p>

   
    <a href="/trackdownn/app/bmi" class="btn-primary">
      Try the BMI Calculator
    </a>
  </div>

  <div class="hero-img">
    <img
      src="website/assets/img/trackdownmockup.jpeg"
      alt="Track Down app mock-up with three mobile screens"
      width="480"
      loading="lazy"
    >
  </div>
</section>

<?php
render_footer();
?>
