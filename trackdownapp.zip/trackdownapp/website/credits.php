
<?php include 'partials.php'; render_header('Track Down | Credits'); ?>
<h2>Credits</h2>
<p>Developed by Omar Alharbi (w23058491).</p>
<h3>Tools & Resources</h3>
<ul>
    <li>HTML5, CSS3, PHP8, JavaScript (ES6)</li>
    <li>Images & icons: Made by Omar Alharbi via Canva</li>
</ul>
<?php render_footer(); ?>
