
<?php include 'partials.php'; render_header('Track Down | Reviews'); ?>
<h2>User Reviews</h2>
<div id="featured"></div>
<h3>All Reviews</h3>
<label for="filter">Filter by rating:</label>
<select id="filter">
    <option value="all">All</option>
    <option value="5">5 ★</option>
    <option value="4">4 ★</option>
    <option value="3">3 ★</option>
</select>
<table id="reviewsTable"><thead><tr><th>User</th><th>Rating</th><th>Comment</th></tr></thead><tbody></tbody></table>
<script>
const featured = document.getElementById('featured');
const tableBody = document.querySelector('#reviewsTable tbody');
const filter = document.getElementById('filter');
let reviews = [];
fetch('website/reviews.json')
    .then(r=>r.json())
    .then(data=>{
        reviews = data.map(r=>({
            rating: r.stars,
            comment: r.review_content || '',
            user: r.user?.name || 'Anonymous'
        }));
        showFeatured();
        populateTable();
        setInterval(showFeatured,5000);
    });
function stars(r){return '★'.repeat(r)+'☆'.repeat(5-r);}
function showFeatured(){
    const fiveStar = reviews.filter(r=>r.rating===5);
    const r = fiveStar[Math.floor(Math.random()*fiveStar.length)];
    featured.innerHTML = `<div class="review"><p class="rating">${stars(r.rating)}</p><h4>${r.comment||'No review text'}</h4><small>— ${r.user}</small></div>`;
}
function populateTable(){
    tableBody.innerHTML='';
    const selected = filter.value==='all'?reviews:reviews.filter(r=>r.rating==filter.value);
    selected.forEach(r=>{
        const tr=document.createElement('tr');
        tr.innerHTML=`<td>${r.user}</td><td>${stars(r.rating)}</td><td>${r.comment}</td>`;
        tableBody.appendChild(tr);
    });
}
filter.addEventListener('change',populateTable);
</script>
<?php render_footer(); ?>
