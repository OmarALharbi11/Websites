<?php
function render_header(string $title): void
{
    echo '<!DOCTYPE html>';
    echo '<html lang="en">';
    echo '<head>';
    echo '<meta charset="UTF-8">';
    echo '<meta name="viewport" content="width=device-width, initial-scale=1.0">';

    
    echo '<link rel="stylesheet" href="/trackdownn/website/assets/css/style.css">';

    
    echo '<base href="/trackdownn/">';

    echo "<title>{$title}</title>";
    echo '</head>';
    echo '<body>';

    
    echo '<header>';
    echo '<img src="website/assets/img/logo.png" alt="Track Down logo" class="logo">';
    echo '<h1>Track Down</h1>';
    echo '<nav><ul>';
    echo '<li><a href="website/index.php">Home</a></li>';
    echo '<li><a href="website/reviews.php">Reviews</a></li>';
    echo '<li><a href="website/credits.php">Credits</a></li>';
    echo '<li><a href="app/journal">Journaling</a></li>';
    echo '<li><a href="app/bmi">BMI (PWA)</a></li>';
    echo '</ul></nav>';
    echo '</header>';
    echo '<main>';
}


function render_footer(): void
{
    echo '</main>';
    echo '<footer><p>&copy; ' . date('Y') . ' Track Down</p></footer>';
    echo '</body></html>';
}
?>
