
<?php include 'partials.php'; render_header('Page Not Found'); ?>
<h2>404 – Page not found</h2>
<p>The page you are looking for doesn’t exist.</p>
<?php render_footer(); ?>
