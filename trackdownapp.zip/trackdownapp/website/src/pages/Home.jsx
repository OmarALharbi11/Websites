
export default function Home(){
  return (
    <section className="text-center space-y-4">
      <img src="logo.png" alt="Track Down" className="mx-auto w-24"/>
      <h2 className="text-2xl font-semibold">Your all in ONE health journal</h2>
      <p>Track calories, workouts, and daily habits in one place. Get insights and stay motivated!</p>
    </section>
  )
}
