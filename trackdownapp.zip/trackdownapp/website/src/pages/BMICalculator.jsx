
import { useState } from 'react';

export default function BMICalculator() {
  const [weight, setWeight] = useState('');    
  const [height, setHeight] = useState('');    
  const [bmi, setBmi]       = useState(null);

  function calculate(e) {
    e.preventDefault();
    const kg = parseFloat(weight);
    const m  = parseFloat(height) / 100;
    if (kg > 0 && m > 0) {
      const value = kg / (m * m);
      setBmi(value.toFixed(1));
    }
  }

  function reset() {
    setWeight(''); setHeight(''); setBmi(null);
  }

  return (
    <section className="max-w-md mx-auto space-y-4">
      <h2 className="text-2xl font-semibold text-center">BMI Calculator</h2>

      <form onSubmit={calculate} className="space-y-2">
        <div>
          <label className="block">Weight (kg):</label>
          <input
            type="number"
            step="0.1"
            value={weight}
            onChange={e => setWeight(e.target.value)}
            className="w-full border p-2 rounded"
            required
          />
        </div>
        <div>
          <label className="block">Height (cm):</label>
          <input
            type="number"
            step="0.1"
            value={height}
            onChange={e => setHeight(e.target.value)}
            className="w-full border p-2 rounded"
            required
          />
        </div>
        <div className="flex space-x-2">
          <button type="submit" className="flex-1 bg-primary text-white py-2 rounded">
            Calculate
          </button>
          <button type="button" onClick={reset} className="flex-1 border py-2 rounded">
            Reset
          </button>
        </div>
      </form>

      {bmi !== null && (
        <div className="p-4 border rounded bg-gray-50">
          <p>Your BMI is <strong>{bmi}</strong>.</p>
          <p>
            Category:{' '}
            {bmi < 18.5 ? 'Underweight' :
             bmi < 25   ? 'Normal weight' :
             bmi < 30   ? 'Overweight' :
                         'Obesity'}
          </p>
        </div>
      )}
    </section>
  );
}
