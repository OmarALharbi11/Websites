
import { useEffect, useState } from 'react'
import EntryForm from '../components/EntryForm'
import EntryList from '../components/EntryList'
const STORAGE_KEY = 'td_entries'
export default function Journal(){
  const [entries,setEntries]=useState([])
  const [editIndex,setEditIndex]=useState(null)
  useEffect(()=>{ const saved=localStorage.getItem(STORAGE_KEY); if(saved) setEntries(JSON.parse(saved)) },[])
  useEffect(()=>{ localStorage.setItem(STORAGE_KEY,JSON.stringify(entries)) },[entries])
  function saveEntry(data){
    if(editIndex!==null){
      const copy=[...entries]; copy[editIndex]=data; setEntries(copy); setEditIndex(null)
    } else {
      setEntries([...entries,data])
    }
  }
  function editEntry(i){ setEditIndex(i) }
  function deleteEntry(i){ setEntries(entries.filter((_,idx)=>idx!==i)) }
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold">{editIndex!==null?'Edit Entry':'New Entry'}</h2>
      <EntryForm onSave={saveEntry} initial={editIndex!==null?entries[editIndex]:null}/>
      <h2 className="text-xl font-bold">Entries</h2>
      <EntryList entries={entries} onEdit={editEntry} onDelete={deleteEntry}/>
    </div>
  )
}
