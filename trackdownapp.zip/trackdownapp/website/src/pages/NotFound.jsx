
import { Link } from 'react-router-dom'
export default function NotFound(){
  return (
    <div className="text-center space-y-4">
      <h2 className="text-3xl font-bold">404 – Page not found</h2>
      <Link to="/" className="text-primary underline">Go Home</Link>
    </div>
  )
}
