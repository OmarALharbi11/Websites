import { Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home';
import Journal from './pages/Journal';
import BMICalculator from './pages/BMICalculator';
import NotFound from './pages/NotFound';

export default function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-primary text-white p-4 flex justify-between items-center">
        <h1 className="text-xl font-bold">Track Down</h1>
        <nav className="space-x-4">
          <Link to="/">Home</Link>
          <Link to="/journal">Journal</Link>
          <Link to="/bmi">BMI</Link>
        </nav> 
      </header>
      <main className="flex-1 p-4">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/journal" element={<Journal />} />
          <Route path="/bmi" element={<BMICalculator />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <footer className="bg-primary text-white p-2 text-center">
        &copy; {new Date().getFullYear()} Track Down
      </footer>
    </div>
  );
}
