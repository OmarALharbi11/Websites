
export default function EntryList({entries,onEdit,onDelete}){
  if(!entries.length) return <p>No entries yet.</p>
  return (
    <table className="w-full border">
      <thead><tr><th>Date</th><th>Meal</th><th>Calories</th><th>Workout</th><th>Notes</th><th></th></tr></thead>
      <tbody>
      {entries.map((e,i)=>(
        <tr key={i} className="border-t">
          <td>{e.date}</td><td>{e.meal}</td><td>{e.calories}</td><td>{e.workout}</td><td>{e.notes}</td>
          <td>
            <button onClick={()=>onEdit(i)} className="text-primary mr-2">Edit</button>
            <button onClick={()=>onDelete(i)} className="text-red-600">Delete</button>
          </td>
        </tr>
      ))}
      </tbody>
    </table>
  )
}
