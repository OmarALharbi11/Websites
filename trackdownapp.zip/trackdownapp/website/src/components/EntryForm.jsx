
import { useState } from 'react'
export default function EntryForm({onSave, initial}){
  const [entry, setEntry] = useState(initial||{date:'',meal:'',calories:'',workout:'',notes:''})
  function handleSubmit(e){
    e.preventDefault()
    onSave(entry)
    setEntry({date:'',meal:'',calories:'',workout:'',notes:''})
  }
  return (
    <form onSubmit={handleSubmit} className="space-y-2">
      <input required type="date" value={entry.date} onChange={e=>setEntry({...entry,date:e.target.value})} className="border p-1 w-full"/>
      <input placeholder="Meal" value={entry.meal} onChange={e=>setEntry({...entry,meal:e.target.value})} className="border p-1 w-full"/>
      <input type="number" placeholder="Calories" value={entry.calories} onChange={e=>setEntry({...entry,calories:e.target.value})} className="border p-1 w-full"/>
      <input placeholder="Workout" value={entry.workout} onChange={e=>setEntry({...entry,workout:e.target.value})} className="border p-1 w-full"/>
      <textarea placeholder="Notes" value={entry.notes} onChange={e=>setEntry({...entry,notes:e.target.value})} className="border p-1 w-full"/>
      <button className="bg-primary text-white px-4 py-1 rounded">Save</button>
    </form>
  )
}
